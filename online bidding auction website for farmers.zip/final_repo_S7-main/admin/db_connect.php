<?php 
$conn= new mysqli('database-1.cwa1v3hdvy5b.us-east-1.rds.amazonaws.com','admin','admin123','kk')or die("Could not connect to mysql".mysqli_error($con));
?>